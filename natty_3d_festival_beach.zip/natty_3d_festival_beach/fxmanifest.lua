fx_version 'bodacious'
games {'gta5'}
